<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Riwayat Redeem SN</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <!--  -->
                    <form action="<?php echo e(route('simpan_riw')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label>SN</label>
                            <select class="form-control select2 select2-danger select2-hidden-accessible"
                                data-dropdown-css-class="select2-danger" style="width: 100%;" data-select2-id="12"
                                tabindex="-1" aria-hidden="true" name="sn">
                                <option value="">Pilih SN</option>
                                <?php $__currentLoopData = $data_sn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->sn); ?>"><?php echo e($item->sn." - ".$item->judul); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <!-- <label>Reward</label>
                            <select class="form-control select2 select2-danger select2-hidden-accessible"
                                data-dropdown-css-class="select2-danger" style="width: 100%;" data-select2-id="12"
                                tabindex="-1" aria-hidden="true" name="judul">
                                <option value="">Pilih SN</option>
                                <?php $__currentLoopData = $data_sn; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->sn); ?>"><?php echo e($item->judul); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select> -->
                        </div>

                        <div class="form-group">
                            <label>User</label>
                            <select class="form-control select2 select2-danger select2-hidden-accessible"
                                data-dropdown-css-class="select2-danger" style="width: 100%;" data-select2-id="12"
                                tabindex="-1" aria-hidden="true" name="user">
                                <option value="">Pilih User</option>
                                <?php $__currentLoopData = $data_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->name); ?>"><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <!-- select -->
                        <div class="form-group" name="status">
                            <label>Status</label>
                            <select class="form-control" id="opsi_status" name="status">
                                <option value="Selesai" id="Selesai">Selesai</option>
                                <option value="Belum Selesai" id="Belum_selesai">Belum Selesai</option>
                            </select>
                        </div>
                        <div class="form-group mb-4">
                            <button type="submit" class="btn btn-primary btn-mb-4">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebAdminScanner2\resources\views/riwayatSN/create_riw.blade.php ENDPATH**/ ?>