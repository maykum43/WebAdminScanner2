<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Data Customer</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('update_user',$data->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-3">
                            <label>Nama</label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($data->name); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Email</label>
                            <input type="text" name="email" class="form-control" value="<?php echo e($data->email); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Telepon</label>
                            <input type="number" name="phone" class="form-control" value="<?php echo e($data->phone); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>No. Rekening</label>
                            <input type="number" name="norek" class="form-control" value="<?php echo e($data->norek); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>BANK</label>
                            <input type="text" name="nama_bank" class="form-control" value="<?php echo e($data->nama_bank); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Atas Nama</label>
                            <input type="text" name="atas_nama" class="form-control" value="<?php echo e($data->atas_nama); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Username Akun Online Shop</label>
                            <input type="text" name="nama_akun_ol" class="form-control" value="<?php echo e($data->nama_akun_ol); ?>">
                        </div>
                      <!-- select -->
                      <div class="form-group" name="status">
                        <label>Status</label>
                        <select class="form-control" id="opsi_status" name="status">
                            <option><?php echo e($data->status); ?></option>
                          <option value="Aktif" id="Aktif">Aktif</option>
                          <option value="Nonaktif" id="Nonaktif">Nonktif</option>
                        </select>
                      </div>
                <div class="form-group mb-4">
                    <button type="submit" class="btn btn-primary btn-mb-4">Simpan</button>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebAdminScanner2\resources\views/customer/edit_cust.blade.php ENDPATH**/ ?>