<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Data SN Cashback</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('update_sn',$data->id_sn)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group mb-3">
                            <label>SN</label>
                            <input type="text" name="sn" class="form-control" value="<?php echo e($data->sn); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Judul</label>
                            <input type="text" name="judul" class="form-control" value="<?php echo e($data->judul); ?>">
                        </div>
                        <div class="form-group mb-3">
                            <label>Harga</label>
                            <input type="number" name="harga" class="form-control" value="<?php echo e($data->harga); ?>">
                        </div>
                      <!-- select -->
                      <div class="form-group" name="status">
                        <label>Status</label>
                        <select class="form-control" id="opsi_status" name="status">
                            <option><?php echo e($data->status); ?></option>
                          <option value="Aktif" id="Aktif">Aktif</option>
                          <option value="Nonaktif" id="Nonaktif">Nonktif</option>
                        </select>
                      </div>
                <div class="form-group mb-4">
                    <button type="submit" class="btn btn-primary btn-mb-4">Simpan</button>
                </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebAdminScanner2\resources\views/sn/edit_sn.blade.php ENDPATH**/ ?>