<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Data Customer</div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <form method="GET" action="<?php echo e(route('customer')); ?>">
                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="cari_user" placeholder="Masukan Nama Customer">
                            <div class="input-group-prepend">
                                <button class="btn btn-success" type="submit">Cari User</button>
                            </div>
                            <!-- /btn-group -->

                        </div>
                    </form>

                    <!-- <a href="" class="btn btn-sm btn-primary float-end">Tambah Data</a> -->
                    <!-- <p> -->

                    <table id="example1" class="table table-bordered table-striped dataTable dtr-inline" role="grid"
                        aria-describedby="example1_info">
                        <thead>
                            <tr role="row">
                                <th class="sorting sorting_asc" tabindex="0" aria-controls="example1" rowspan="1"
                                    colspan="1" aria-sort="ascending"
                                    aria-label="Rendering engine: activate to sort column descending">No.
                                </th>
                                <!-- <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">ID Customer</th> -->
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    Email</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    Nama</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    No.Telepon</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    No.Rekening</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    Bank</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    Atas Nama</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    ID Online Shop</th>
                                <th class="sorting" tabindex="0" aria-controls="example1" rowspan="1" colspan="1"
                                    aria-label="Browser: activate to sort column ascending">
                                    Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i = 1;
                            ?>

                            <?php $__currentLoopData = $cust; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($data->email); ?></td>
                                <td><?php echo e($data->name); ?></td>
                                <td><?php echo e($data->phone); ?></td>
                                <td><?php echo e($data->norek); ?></td>
                                <td><?php echo e($data->nama_bank); ?></td>
                                <td><?php echo e($data->atas_nama); ?></td>
                                <td><?php echo e($data->nama_akun_ol); ?></td>
                                <td><?php echo e($data->status); ?></td>
                                <td>
                                    <div class="btn-group">
                                        <a href="" 
                                            class="btn btn-success btn-sm">Detail</a>
                                        <a href="<?php echo e(route('edit_user',$data->id)); ?>" 
                                            class="btn btn-warning btn-sm">Edit</a>
                                        <a href="<?php echo e(route('delete_user',$data->id)); ?>" 
                                            class="btn btn-danger btn-sm">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WebAdminScanner2\resources\views/customer/data_cust.blade.php ENDPATH**/ ?>